// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception> // included to define a custom exception

using namespace std;

// Define a new exception structure that contains an overridden what() method explaining the exception
struct new_exception : public exception
{
    virtual const char* what() const throw()
    {
        return "Exception: My custom exception happened.";
    }
} newException;

bool do_even_more_custom_application_logic()
{
    cout << "Running Even More Custom Application Logic." << endl;

    // TODO: Throw any standard exception
    throw runtime_error("Exception: Do even more custom application logic exception happened.");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    cout << "Running Custom Application Logic." << endl;

    // Try to do even more custom application logic. However, the method throws a runtime error, and the success message should not be printed.
    try
    {
        if (do_even_more_custom_application_logic())
        {
            cout << "Even More Custom Application Logic Succeeded." << endl;
        }
    }
    catch (runtime_error runtimeException)
    {
        cout << runtimeException.what() << endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    throw newException;

    cout << "Leaving Custom Application Logic." << endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    
    // If the denominator is 0, an invalid argument is thrown: Exception: Cannot divide by zero.
    if (den == 0)
    {
        throw invalid_argument("Exception: Cannot divide by zero.");
    }
    else
    {
        return (num / den);
    }
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0.0f;

    auto result = 0.0f;

    // Try to get the result of the division. If an exception is thrown, the result is not displayed; but the exception message is.
    try
    {
        result = divide(numerator, denominator);
        cout << "divide(" << numerator << ", " << denominator << ") = " << result << endl;
    }
    catch (invalid_argument& invArgException)
    {
        cout << invArgException.what() << endl;
    }
}

int main()
{
    cout << "Exceptions Tests!" << endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (new_exception& newExc)
    {
        cout << newExc.what() << endl;
    }
    catch (exception& exception) // catch exceptions from std::exception
    {
        cout << "Exception: " << exception.what() << endl;
    }
    catch (...) // catch all other exceptions
    {
        cout << "Exception: some kind of exception was caught." << endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu